#include "lib.h"

void ClassLib::Set(int value) {
    x_ = value;    
}

int ClassLib::Get() const {
    return x_;
}
